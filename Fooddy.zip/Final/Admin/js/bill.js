const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString)
const tablenumber = urlParams.get('tablenumber')
$('#tableid').html(tablenumber)


load = () => {
    $.post(
        '../admin/php/tablefood.php',
        { tablenumber },
        (data, response) => {
            if (response === 'success') {
                data = JSON.parse(data)
                var table = `
                    <table class="table mt-3">
                    <thead>
                        <tr>
                            <th scope="col">Sr. No</th>
                            <th scope="col">Food Item</th>
                            <th scope="col">Price</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Total</th>
                        </tr>
                    </thead>
                `;
                var subtotal = 0
                var i =1
                data.forEach((ele) => {
                    table += `
                        <tr>
                            <td class="col-1">${i}</td>
                            <th scope="row">${ele.fooditem}</th>
                            <td class="col-1">${ele.foodprice}</td>
                            <td class="col-1">${ele.quantity}</td>
                            <td class="col-1">${ele.total}</td>
                        </tr>
                    `
                    subtotal += Number.parseInt(ele.total)
                    i++
                })
                table += '</table>'
                document.getElementById('table').innerHTML = table
                $('#subtotal').html(subtotal)
                $('#tax').html(subtotal*8/100)
                $('#total').html(parseFloat(subtotal+(subtotal*8/100)).toFixed(2));
            }
        }
    )
}

function invoice() {
    // alert('hi');
    var params = {
        to_name: document.getElementById("name").value,
        to_email: document.getElementById("email").value,
        from_name: "Fooddy",
        msg: document.getElementById("msg").value,
    };
    const serviceID = "service_pl6l8u4";
    const templateID = "template_28ikarl";

    emailjs.send(serviceID, templateID, params).then(function (res) {
        alert("Success! " + res.status);
    })
}

function validateemail(inputText) {
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (inputText.value.match(mailformat)) {
        alert("Valid email address!");
        document.form1.text1.focus();
        return true;
    }
    else {
        alert("You have entered an invalid email address!");
        document.form1.text1.focus();
        return false;
    }
}

load()