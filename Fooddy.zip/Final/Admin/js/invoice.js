function invoice() {
    // alert('hi');
    var params = {
        to_name: document.getElementById("name").value,
        to_email: document.getElementById("email").value,
        from_name: "Fooddy",
        msg: document.getElementById("msg").value,
    };
    const serviceID = "service_pl6l8u4";
    const templateID = "template_28ikarl";

    emailjs.send(serviceID, templateID, params).then(function (res) {
        alert("Success! " + res.status);
    })
}

function validateemail(inputText) {
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (inputText.value.match(mailformat)) {
        alert("Valid email address!");
        document.form1.text1.focus();
        return true;
    }
    else {
        alert("You have entered an invalid email address!");
        document.form1.text1.focus();
        return false;
    }
}
