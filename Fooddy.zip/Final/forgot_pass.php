<?php
	// include_once "resource/session.php";
				$servername = "localhost";
				$username = "root";
				$password = "";
				$dbname = "register";

				// Create connection
				$conn = new mysqli($servername, $username, $password, $dbname);
				// Check connection
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				} 
				
		
?>









<!DOCTYPE html>
<html >
<head>
<meta charset="utf-8" />
     <meta name="viewport" content="width=device-width, initial-scale=1" />
     <link rel="icon" type="image/png" href="Home/image/logo-1.png">


     <!-- Bootstrap CSS -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous" />
     <link rel="stylesheet" href="Home/home.css">

    
	<title>Forget Password</title>
  
  
  
</head>
<!--img src = "img/background3.jpg" id = "fsbg" width = "100%" height ="auto" style = "margin-top:0px; z-index: -100; min-width: 1040px;min-height: 100%;margin-left: 0px; position: fixed;"-->
<body>


<div align = "center" style = "height: 75%;">
  <div class="login-form"  style = "margin-top: 75px;">
  <div class = "thumbnail" style="width: 50%; margin:auto; background-color: #f9fafb94">

    <form method = "POST" style = "width:80%; margin: auto;">
	<h1>
                    <a href="./Home.php">
                        <img src="./logo-1.png" alt="Fooddy" target>
                   </a>
                </h1>
	 <h3>Password Reset</h3>
	 
			<?php
			
				if(isset($_POST['paswordResetBtn'])){
					$email = $_POST['email'];
					$password1 = $_POST['new_password'];
					$password2 = $_POST['confirm_password'];
				
						if($password1 != $password2){
						?>
				
							<script type = "text/javascript">
							alert("Passwords do not match");
							window.location.href = "forgot_pass.php";
							</script>

							<?php
						
						}
						else{
							$sqlQuery = "SELECT * FROM users WHERE email = '$email'";
							$run_user = mysqli_query($conn, $sqlQuery);
				
							$check_user = mysqli_num_rows($run_user);
				
							if($check_user > 0){
									$hashed_password = password_hash($password, PASSWORD_DEFAULT);
									$sqlUpdate = "UPDATE users SET password = '$password1' WHERE email = '$email'";
									$run_user = mysqli_query($conn, $sqlUpdate);
									
								?>
				
									<script type = "text/javascript">
									alert("Password Reset Successful");
									window.location.href = "Home.php";
									</script>

							<?php
							
							}
							else{
								?>
				
									<script type = "text/javascript">
									alert("Invalid Password");
									window.location.href = "forgot_pass.php";
									</script>

							<?php
								}
						
						}
				
				
				}
			
			?>
			 <div class="form-group">
			   <input type="email" class="form-control"  id="UserName" name ="email" placeholder="Email" value = ""  >
			   <i class="fa fa-user"></i>
			 </div>
			 <div class="form-group log-status">
			   <input type="password" class="form-control" minlength="8" placeholder="New Password" id="Passwod" name = "new_password">
			   <i class="fa fa-lock"></i>
			 </div>
			 <div class="form-group log-status">
			   <input type="password" class="form-control" minlength="8" placeholder="Confirm Password" id="Passwod" name = "confirm_password">
			   <i class="fa fa-lock"></i>
			 </div>
			  </br>
			  <div align = "center">
			 <button style =" width: 45%;" name = "paswordResetBtn" type="submit" class="btn btn-primary" ><strong>RESET</strong></button>
			</br>
			</br>
			<footer style = "margin-top: 1rem;">
										<hr style = "border-top: 1px solid #ccc;">
										<p align = "center">Contact Us: +91 9998332031
											&copy; Fooddy. All rights reserved</p>
								
		</footer>
			</div>
			</form>
		   </div>
		   </div>
		  </div>
		   
				

   
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="js/index.js"></script>
	
</body>
</html>
