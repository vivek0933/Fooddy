-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 01, 2023 at 05:23 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fooddy`
--

-- --------------------------------------------------------

--
-- Table structure for table `managment`
--

CREATE TABLE `managment` (
  `id` int(11) NOT NULL,
  `foodid` int(11) DEFAULT NULL,
  `fooditem` varchar(50) DEFAULT NULL,
  `foodprice` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `tablenumber` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `managment`
--

INSERT INTO `managment` (`id`, `foodid`, `fooditem`, `foodprice`, `quantity`, `total`, `tablenumber`, `status`) VALUES
(0, 107, 'noodle', 80, 1, 80, 3, 0),
(60, 46, 'noodle', 80, 1, 80, 6, 1),
(63, 42, 'sprite', 20, 1, 20, 2, 1),
(72, 37, 'string', 20, 2, 40, 6, 0),
(74, 84, 'manchurian', 90, 1, 90, 6, 0),
(75, 68, 'manchurian', 90, 1, 90, 2, 0),
(76, 91, 'pasta', 120, 1, 120, 2, 0),
(78, 7, 'pizza', 160, 1, 160, 4, 0),
(82, 73, 'pasta', 120, 2, 240, 6, 1),
(84, 90, 'rolls', 80, 1, 80, 3, 1),
(86, 99, 'french fries', 60, 1, 60, 5, 1),
(87, 46, 'chole bhature', 60, 1, 60, 7, 0),
(88, 12, 'cheese burger', 80, 1, 80, 3, 1),
(89, 24, 'pav bhaji', 120, 3, 360, 1, 0),
(91, 74, 'coke', 20, 1, 20, 6, 0),
(92, 3, 'pakoda', 30, 1, 30, 3, 1),
(93, 48, 'burger', 60, 1, 60, 4, 0),
(95, 22, 'Constantina', 74, 1, 74, 4, 0),
(96, 21, 'cheese burger', 80, 2, 160, 5, 0),
(98, 89, 'coca cola', 20, 1, 40, 4, 0),
(99, 61, 'chole bhature', 60, 1, 60, 1, 0),
(100, 83, 'pizza', 160, 2, 320, 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `price` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `name`, `price`) VALUES
(116, 'sprite', '20'),
(109, 'sting', '20'),
(108, 'coke', '20'),
(107, 'noodle', '80'),
(106, 'sandwich', '90'),
(105, 'pasta', '120'),
(104, 'pizza', '160'),
(103, 'cheese burger', '80'),
(102, 'burger', '60'),
(101, 'rolls', '80'),
(100, 'french fries', '60'),
(99, 'pakoda', '30'),
(98, 'pav bhaji', '50'),
(97, 'chole bhature', '60'),
(96, 'manchuriyan', '90'),
(95, 'samosa', '40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `managment`
--
ALTER TABLE `managment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
