<?php
// include_once "resource/session.php";
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "register";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
if (isset($_POST["loginBtn"])) {
	$username = mysqli_real_escape_string($conn, $_POST["username"]);
	$password = mysqli_real_escape_string($conn, $_POST["pass"]);

	$sel_user = "SELECT * FROM products WHERE username = '$username' AND password = '$password'";

	$run_user = mysqli_query($conn, $sel_user);

	$check_user = mysqli_num_rows($run_user);

	if ($check_user > 0) {
		$_SESSION['username'] = $username;
		echo "<script>window.open('Admin/index.html', '_self')</script>";
	} else {
		echo '<script>alert("invalid password or usename")</script>';
	}

}

?>









<!DOCTYPE html>
<html>

<head>


	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="icon" type="image/png" href="Home/image/logo-1.png">


	<!-- Bootstrap CSS -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous" />
	<!-- <link rel="stylesheet" href="Home/home.css"> -->

	<style>
		.foot {
			position: absolute;
			top: 90%;
			left: 50%;
			transform: translate(-50%, -50%);
		}

		body {
            background-image: url(./bg.jpg);
            background-size: cover;
        }
	</style>




</head>
<!--img src = "img/background3.jpg" id = "fsbg" width = "100%" height ="auto" style = "margin-top:0px; z-index: -100; min-width: 1040px;min-height: 100%;margin-left: 0px; position: fixed;"-->

<body>

	<div style="height: 75%;">
		<div class="login-form" style="margin-top: 10%;">
			<div class="thumbnail" style="width: 50%; margin:auto; background-color: #f9fafb94">

				<form method="POST" style="width:80%; margin: auto;">

					<h1 align="center">
						<a href="/Final/Home.php">
							<img src="/final/logo-1.png" alt="Fooddy" target>
						</a>

					</h1>
					<h5 align="center">Admin's Sign In</h5>



					<div class="form-group" align="center">
						<input type="text" class="form-control" id="UserName" name="username" placeholder="Username"
							value="" style="width: 55%; margin-bottom: 5px;">
						<i class="fa fa-user"></i>
					</div>
					<div class="form-group log-status" align="center">
						<input type="password" class="form-control" placeholder="Password" id="Passwod" name="pass"
							style="width: 55%;">
						<i class="fa fa-lock"></i>
					</div>
					<!-- <a class="link" align = "center" style = "padding-left: 150px;"href="register.php">Register Here</a> -->
					<!-- <a class="link" style = "float: right; padding-right: 150px;"href="forgot_pass.php">Lost your password?</a></br> -->
					</br>
					<div align="center">
						<button style=" width: 45%;" name="loginBtn" type="submit" class="btn btn-primary"><strong>SIGN
								IN</strong></button>
						</br>
						</br>
					</div>
				</form>
			</div>
		</div>
	</div>


	<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

	<script src="js/index.js"></script>

	<footer class="foot">
		<hr style="border-top: 1px solid #ccc;">
		<p align="center">Contact Us: +91 9998332031
			&copy; Fooddy. All rights reserved</p>
	</footer>

</body>

</html>