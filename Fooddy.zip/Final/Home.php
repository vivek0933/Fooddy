<!DOCTYPE html>
<html lang="en">
     
<head>
     <!-- Required meta tags -->
     <meta charset="utf-8" />
     <meta name="viewport" content="width=device-width, initial-scale=1" />
     <link rel="icon" type="image/png" href="Home/image/logo-1.png">


     <!-- Bootstrap CSS -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous" />
     <link rel="stylesheet" href="./Home/home.css">

     <title>Fooddy</title>
</head>

<body>
     <!-------- Header ----------->
     <div align = "center" class="Navbar">
          <h1>
               <!-- <a  href="./Home.php"> -->
                    <img src="Home/image/logo-1.png" alt="Fooddy"   width="10%" target >
               <!-- </a> -->

          </h1>
     </div>
     <!-------- content -------->

     <div class="container">

          <!-- Admin  -->

          <div class="card">
               <div class="layer layer1 admin">
                    <div class="content">
                         <img src="https://img.icons8.com/ios/50/000000/admin-settings-male.png" />
                         <h3>Admin</h3>
                    </div>
               </div>
               <div class="layer layer2 admin">
                    <div class="content">
                         <p>Admin can generate bill for each Table. <br> Add,Change and Remove food item in menu
                              with
                              Price and food name. </p>
                         <a href="adminlogin.php" type="button" target="_blank">Access</a>
                    </div>
               </div>
          </div>

          <!-- Cook -->

          <div class=" card">
                              <div class="layer layer1 cook">
                                   <div class="content">
                                        <img src="https://img.icons8.com/glyph-neue/50/000000/cook-male.png" />
                                        <h3>Cook</h3>
                                   </div>
                              </div>
                              <div class="layer layer2 cook">
                                   <div class="content">
                                        <p>Cook provide the information about uncook food and Check food which food.</p>
                                        <a href="cooklogin.php" type="button" target="_blank">Access</a>
                    </div>
               </div>
          </div>

          <!-- Manager -->

          <div class=" card">
                                             <div class="layer layer1 manager">
                                                  <div class="content">
                                                       <img
                                                            src="https://img.icons8.com/external-itim2101-lineal-itim2101/64/000000/external-waiter-male-occupation-avatar-itim2101-lineal-itim2101.png" />
                                                       <h3>Manager</h3>
                                                  </div>
                                             </div>
                                             <div class="layer layer2 manager">
                                                  <div class="content">
                                                       <p>Manager take and update order from customer and provide it to
                                                            Cook and Admin.</p>
<!--                                                  
                                                            <a href="login.html" type="button" target="_blank">Login</a>
                                                             -->
                                        <!--  -->
                                                      <a href="managerlogin.php" type="button" target="_blank">Access</a>
                    </div>
               </div>
          </div>
          

     </div>
     <div style = "height: 100%; align-items: self-end;">
										<!-- <hr style = "border-top: 1px solid #ccc;"> -->
										<p align = "center">Contact Us: +91 9998332031
											&copy; Fooddy. All rights reserved</p>
								
     </div>

          

     <!-------- Bootstrap -------->


     <script src=" https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"
                                                            integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj"
                                                            crossorigin="anonymous">
                                                            </script>
                                                            <script
                                                                 src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"
                                                                 integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp"
                                                                 crossorigin="anonymous">
                                                                 </script>
                                                            <script
                                                                 src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js"
                                                                 integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/"
                                                                 crossorigin="anonymous">
                                                                 </script>
                                                            <script src="https://code.jquery.com/jquery-3.6.0.min.js"
                                                                 integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
                                                                 crossorigin="anonymous"></script>
                                                            
</body>
</html>